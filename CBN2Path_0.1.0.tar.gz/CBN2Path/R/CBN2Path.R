#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom R6 R6Class
#' @importFrom foreach foreach %dopar%
#' @importFrom doMC registerDoMC
## usethis namespace: end
NULL
#' @useDynLib CBN2Path, .registration=TRUE
NULL
